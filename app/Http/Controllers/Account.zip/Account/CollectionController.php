<?php

namespace App\Http\Controllers\Account;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Bank;
use App\Dealer;
use App\Collection;
use DB;

class CollectionController extends Controller
{
    public function index()
    {
        $collections = DB::select('SELECT collections.id,collections.dealer_id,collections.collection_method,collections.collection_date,collections.collection_amount,collections.check_name,collections.check_number,collections.check_date,collections.bank_id,collections.description,banks.bank_name,dealers.d_s_name FROM `collections` 
        LEFT JOIN banks ON banks.id = collections.bank_id
        LEFT JOIN dealers ON dealers.id = collections.dealer_id
        ORDER BY collections.id DESC' );
        return view('Account.Collection.index',compact('collections'));
    }

    public function collection()
    {
        $dealers = Dealer::latest('id')->get();
        $banks = Bank::latest('id')->get();
        return view('Account.Collection.collection',compact('dealers','banks'));
    }

    public function storecollection(Request $request)
    {
        // dd($request);
        $collections = new Collection;
        $collections->dealer_id      = $request->dealer_id;
        $collections->collection_method      = $request->collection_method;
        $collections->collection_date      = $request->collection_date;
        $collections->collection_amount      = $request->collection_amount;
        $collections->check_name      = $request->check_name;
        $collections->check_number      = $request->check_number;
        $collections->check_date      = $request->check_date;
        $collections->bank_id      = $request->bank_id;
        $collections->description      = $request->description;
        $collections->save();
        return redirect()->route('collection.index')
                        ->with('success', 'Collection Set successfully .');

    }
}
